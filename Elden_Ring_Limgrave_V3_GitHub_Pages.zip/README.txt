Elden Ring Limgrave V3

Za puni rad interakcija objavi index.html preko HTTPS (npr. GitHub Pages). Pregled unutar ChatGPT datoteka može blokirati JavaScript. Napredak se sprema lokalno u pregledniku za ovu domenu.
